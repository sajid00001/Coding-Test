﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player_Input_Handler : MonoBehaviour
{

    // Reference to Our Main Missile Object
    public GameObject Missile;
    public List<GameObject> Missile_Objects_Pool;
    // To Display Target Mark where Player has touched
    public GameObject Target_Mark;

    [SerializeField]
    Transform[] Missile_Launchers;

    [SerializeField]
    int Missile_Pool_Size;
    void Start()
    {
        for (int i = 0; i < Missile_Pool_Size; i++)
        {
            GameObject tempGO = Instantiate(Missile);
            Missile_Objects_Pool.Add(tempGO);
        }
    }

    Vector2 Touch_Pos;
    // Update is called once per frame
    void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            Touch_Pos = Input.mousePosition;
            Touch_Pos = Camera.main.ScreenToWorldPoint(Touch_Pos);
            Target_Mark.transform.position = Touch_Pos;
            Target_Mark.SetActive(true);
            Check_touch_Position();
            Invoke("Remove_Target_Mark",0.5f);
        }
    }


    // This is to check the touch position and launch missile from the nearest Launcher
    void Check_touch_Position()
    {
        float D1 = Vector3.Distance(Touch_Pos, Missile_Launchers[0].position);
        float D2 = Vector3.Distance(Touch_Pos, Missile_Launchers[1].position);
        float D3 = Vector3.Distance(Touch_Pos, Missile_Launchers[2].position);
        if (D1 < D2 && D1 < D3)
        {
            Fire_Missile(0);
        }
        else if (D2 < D1 && D2 < D3)
        {
            Fire_Missile(1);
        }
        else
        {
            Fire_Missile(2);
        }
    }

    void Fire_Missile(int Launcher_Index)
    {
        for (int i = 0; i < Missile_Objects_Pool.Count; i++)
        {
            if (Missile_Objects_Pool[i].activeInHierarchy == false)
            {
                Missile_Objects_Pool[i].transform.position = new Vector3(Missile_Launchers[Launcher_Index].position.x, Missile_Launchers[Launcher_Index].position.y,0f);
                Missile_Objects_Pool[i].gameObject.transform.rotation = Quaternion.Euler(Vector3.zero);
                Missile_Objects_Pool[i].SetActive(true);
                LeanTween.move(Missile_Objects_Pool[i], new Vector3(Touch_Pos.x,Touch_Pos.y * 10f,0f), 1f);
                break;  
            }
        }
    }

    void Remove_Target_Mark()
    {
        Target_Mark.SetActive(false);
    }
}
