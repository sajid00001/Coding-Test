﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy_Spawner : MonoBehaviour
{

    // Reference to Our Main Enemy Object
    public GameObject Enemy_Object;

    public List<GameObject> Enemies;
    
   
    [SerializeField]
    Transform[] targets;

    // To Set Size of Our Enemy_Pool
    [SerializeField]
    int Enemy_Pool_Size;
    void Start()
    {
        for (int i = 0; i < Enemy_Pool_Size; i++)
        {
            GameObject tempGo = Instantiate(Enemy_Object);
            Enemies.Add(tempGo);
        }
        StartCoroutine(Launch_Enemy_Projectiles());
    }

    GameObject temp_Object;

    int Random_Target_Index;
    IEnumerator Launch_Enemy_Projectiles()
    {
        yield return null;
        while (Manager.Instance.GameOver == false)
        {
            for (int i = 0; i < Enemies.Count; i++)
            {
                if (Enemies[i].activeInHierarchy == false && Manager.Instance.GameOver == false)
                {
                    Enemies[i].transform.position = new Vector2(0f, 4f);
                    for (int j = 0; j < targets.Length; j++)
                    {
                        if (targets[j].gameObject.activeInHierarchy)
                        {
                            Random_Target_Index = j;
                        }
                    }
                    Enemies[i].SetActive(true);
                    LeanTween.move(Enemies[i], targets[Random_Target_Index].position, 2.5f);
                    temp_Object = Enemies[i];
                }
                yield return new WaitForSeconds(1f);
            }
        }

    }

}
