﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    
    public Vector3 Target_Position;
    Rigidbody2D Enemy_Body;

    void Start()
    {
       // Enemy_Body = GetComponent<Rigidbody2D>();
    }

    void OnEnable()
    {
        X_Pos = gameObject.transform.position.x;
        Y_Pos = gameObject.transform.position.y;
    }
    float X_Pos, Y_Pos;
    // Update is called once per frame
    void FixedUpdate()
    {
        X_Pos = Mathf.MoveTowards(X_Pos, Target_Position.x, 0.1f);
        Y_Pos = Mathf.MoveTowards(Y_Pos, Target_Position.y, 0.1f);
        //Enemy_Body.MovePosition(new Vector2(X_Pos, Y_Pos));
    }

    void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Alive")
        {
            collision.gameObject.SetActive(false);
            Manager.Instance.Base_Object_Destroyed();
            gameObject.SetActive(false);
        }
        else if (collision.gameObject.tag == "Missile")
        {
            collision.gameObject.SetActive(false);
            Manager.Instance.Player_Scored();
            gameObject.SetActive(false);
        }
        else if (collision.gameObject.tag == "Ground")
        {
            gameObject.SetActive(false);
        }
    }
}
