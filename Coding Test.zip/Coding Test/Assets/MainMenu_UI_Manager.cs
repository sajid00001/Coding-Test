﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenu_UI_Manager : MonoBehaviour
{

    // This would be used for Our Main Menu Start Button
    public void Start_Button()
    {
        SceneManager.LoadScene(1);
    }


    public void Options_Button()
    {

    }
}
