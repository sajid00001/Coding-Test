﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Manager : MonoBehaviour
{
    public static Manager Instance;

    public Text Score_Text;
    int score_count;
    void Awake()
    {
        Instance = this;
        if (Instance != this)
        {
            Destroy(Instance);
        }
        GameOver = false;
        score_count = 0;
        Destroyed_Objects_Count = 0;
    }

    public bool GameOver;
    [SerializeField]
    int Destroyed_Objects_Count;

    public GameObject Restart_Panel,Ground;
    public void Base_Object_Destroyed()
    {
        Destroyed_Objects_Count++;
        if (Destroyed_Objects_Count == 9)
        {
            GameOver = true;
            Ground.SetActive(false);
            Restart_Panel.SetActive(true);
        }
    }

    public void Restart_Button()
    {
        SceneManager.LoadScene(0);
    }

    public void Player_Scored()
    {
        score_count += 25;
        Score_Text.text = "SCORE : " + score_count.ToString();
    }
}
